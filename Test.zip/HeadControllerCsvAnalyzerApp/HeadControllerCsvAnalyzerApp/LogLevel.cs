﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeadControllerCsvAnalyzerApp
{
    internal class LogLevel
    {
        public static LogLevel Fatal = new LogLevel("FATAL");
        public static LogLevel Error = new LogLevel("ERROR");
        public static LogLevel Warn = new LogLevel("WARN");
        public static LogLevel Info = new LogLevel("INFO");
        public static LogLevel Debug = new LogLevel("DEBUG");

        public string Name { get; }

        public LogLevel(string name)
        {
            Name = name;
        }

        public static LogLevel Parse(string text)
        {
            return new LogLevel(text);
        }

        public override bool Equals(object? obj)
        {
            return obj is LogLevel level && Name == level.Name;
        }
    }
}
