﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeadControllerCsvAnalyzerApp
{
    internal class LogData
    {
        public static DataColumn[] GetHeader()
        {
            return new DataColumn[]
            {
                new DataColumn("Date", typeof(DateTime)),
                new DataColumn("Time", typeof(TimeSpan)),
                new DataColumn("Version"),
                new DataColumn("LogLevel"),
                new DataColumn("Class"),
                new DataColumn("Message"),
                new DataColumn("Exception")
            };
        }

        public static LogData Parse(string text)
        {
            var split = text.Split(',');

            return new LogData(
                DateTime.Parse(split[0]),
                Version.Parse(split[1]),
                LogLevel.Parse(split[2]),
                split[3],
                split[4],
                split[5]);
        }

        internal object[] ToRow()
        {
            //Headerと同じ順番に格納
            return new object[]
            {
                DateTimeInfo.Date,
                DateTimeInfo.TimeOfDay,
                VersionInfo.ToString(),
                LogLevel.Name,
                ClassName,
                Message,
                Exception
            };
        }

        public LogData(DateTime dateTime, Version version, LogLevel logLevel, string className, string message, string exception)
        {
            DateTimeInfo = dateTime;
            VersionInfo = version;
            LogLevel = logLevel;
            ClassName = className;
            Message = message;
            Exception = exception;
        }

        public string GetDateText() => DateTimeInfo.Date.ToString("yyyy/MM/dd");

        public DateTime DateTimeInfo { get; }
        public Version VersionInfo { get; }
        public LogLevel LogLevel { get; }
        public string ClassName { get; }
        public string Message { get; }
        public string Exception { get; }
    }
}
