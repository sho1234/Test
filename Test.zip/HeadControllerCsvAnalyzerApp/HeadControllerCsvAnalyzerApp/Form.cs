using System.Data;
using System.Windows.Forms;

//start�ŏ��Ԃɉ{��
//�������b�Z�[�W�̓��[�v�J�E���g�ŏȗ�
//�����t�@�C���ǂݍ���
//�m�C�Y�ɂȂ郁�b�Z�[�W�����O
//�v�����E���information�ɋL��

namespace HeadControllerCsvAnalyzerApp
{
    public partial class Form : System.Windows.Forms.Form
    {
        private bool updateFlag = true;
        private List<LogData> logDataList = new List<LogData>();

        public Form()
        {
            InitializeComponent();
        }

        private void OpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    LoadFromCsv(openFileDialog.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("OpenError: " + ex.Message);
                }
            }
        }

        private void LoadFromCsv(string filePath)
        {
            logDataList.Clear();
            logDataList.AddRange(File.ReadAllLines(filePath).Skip(1).Select(LogData.Parse));
            UpdateDateDropDownList();
            UpdateDataGridView();
        }

        private void UpdateDateDropDownList()
        {
            dateComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            dateComboBox.Items.Clear();
            dateComboBox.Items.Add("ALL");
            dateComboBox.Items.AddRange(logDataList.Select(logData => logData.GetDateText()).Distinct().ToArray());
            dateComboBox.SelectedIndex = 0;
        }

        private void UpdateDataGridView()
        {
            if (!updateFlag) return;

            try
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.AddRange(LogData.GetHeader());

                var filterList = logDataList
                    .Where(logData =>
                        {
                            if (fatalCheckBox.Checked && logData.LogLevel.Equals(LogLevel.Fatal)) return true;
                            if (errorCheckBox.Checked && logData.LogLevel.Equals(LogLevel.Error)) return true;
                            if (warnCheckBox.Checked && logData.LogLevel.Equals(LogLevel.Warn)) return true;
                            if (infoCheckBox.Checked && logData.LogLevel.Equals(LogLevel.Info)) return true;
                            if (infoCheckBox.Checked && logData.LogLevel.Equals(LogLevel.Debug)) return true;
                            return false;
                        })
                    .Where(logData =>
                        {
                            if (dateComboBox.SelectedIndex == 0) return true;
                            return logData.GetDateText() == dateComboBox.Text;
                        }
                    );

                foreach (var logData in filterList)
                {
                    dataTable.Rows.Add(logData.ToRow());
                }

                dataGridView.DataSource = dataTable;
                dataGridView.Columns[5].MinimumWidth = 300;
                dataGridView.Columns[6].MinimumWidth = 300;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView.SelectedCells.Count <= 0) return;
            if (dataGridView.SelectedCells[0].Value != null)
            {
                selectedContents.Text = dataGridView.SelectedCells[0].Value.ToString();
            }
        }

        private void filterChanged(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }

        private void dateNextButton_Click(object sender, EventArgs e)
        {
            var currentIndex = dateComboBox.SelectedIndex;
            if(currentIndex < dateComboBox.Items.Count - 1) dateComboBox.SelectedIndex++;
        }

        private void dateBackButton_Click(object sender, EventArgs e)
        {
            var currentIndex = dateComboBox.SelectedIndex;
            if(currentIndex != 0) dateComboBox.SelectedIndex--;
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            updateFlag = false;
            fatalCheckBox.Checked = true;
            errorCheckBox.Checked = true;
            warnCheckBox.Checked = true;
            infoCheckBox.Checked = true;
            dateComboBox.SelectedIndex = 0;
            updateFlag = true;

            UpdateDataGridView();
        }

        private void dataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            for(var i = 0; i < dataGridView.Rows.Count; i++)
            {
                for (var j = 0; j < dataGridView.Rows[i].Cells.Count; j++)
                {
                    if (dataGridView.Rows[i].Cells[5].Value.ToString() == "Start")
                    {
                        dataGridView.Rows[i].Cells[j].Style.BackColor = Color.Yellow;
                    }
                    else
                    {
                        dataGridView.Rows[i].Cells[j].Style.BackColor = dataGridView.DefaultCellStyle.BackColor;;
                    }
                }
            }
        }
    }
}