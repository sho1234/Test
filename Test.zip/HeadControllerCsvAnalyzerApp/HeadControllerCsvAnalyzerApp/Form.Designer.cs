﻿namespace HeadControllerCsvAnalyzerApp
{
    partial class Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.footerSplitContainer = new System.Windows.Forms.SplitContainer();
            this.dataGridSplitContainer = new System.Windows.Forms.SplitContainer();
            this.headerSplitContainer = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.dateNextButton = new System.Windows.Forms.Button();
            this.dateBackButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.infoCheckBox = new System.Windows.Forms.CheckBox();
            this.warnCheckBox = new System.Windows.Forms.CheckBox();
            this.errorCheckBox = new System.Windows.Forms.CheckBox();
            this.fatalCheckBox = new System.Windows.Forms.CheckBox();
            this.dateComboBox = new System.Windows.Forms.ComboBox();
            this.information = new System.Windows.Forms.RichTextBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.selectedContents = new System.Windows.Forms.RichTextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.footerSplitContainer)).BeginInit();
            this.footerSplitContainer.Panel1.SuspendLayout();
            this.footerSplitContainer.Panel2.SuspendLayout();
            this.footerSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSplitContainer)).BeginInit();
            this.dataGridSplitContainer.Panel1.SuspendLayout();
            this.dataGridSplitContainer.Panel2.SuspendLayout();
            this.dataGridSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.headerSplitContainer)).BeginInit();
            this.headerSplitContainer.Panel1.SuspendLayout();
            this.headerSplitContainer.Panel2.SuspendLayout();
            this.headerSplitContainer.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1128, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルToolStripMenuItem
            // 
            this.ファイルToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ファイルToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenToolStripMenuItem});
            this.ファイルToolStripMenuItem.Name = "ファイルToolStripMenuItem";
            this.ファイルToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.ファイルToolStripMenuItem.Text = "ファイル";
            // 
            // OpenToolStripMenuItem
            // 
            this.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem";
            this.OpenToolStripMenuItem.Size = new System.Drawing.Size(93, 22);
            this.OpenToolStripMenuItem.Text = "開く";
            this.OpenToolStripMenuItem.Click += new System.EventHandler(this.OpenToolStripMenuItem_Click);
            // 
            // footerSplitContainer
            // 
            this.footerSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.footerSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.footerSplitContainer.Location = new System.Drawing.Point(0, 24);
            this.footerSplitContainer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.footerSplitContainer.Name = "footerSplitContainer";
            this.footerSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // footerSplitContainer.Panel1
            // 
            this.footerSplitContainer.Panel1.Controls.Add(this.dataGridSplitContainer);
            // 
            // footerSplitContainer.Panel2
            // 
            this.footerSplitContainer.Panel2.Controls.Add(this.selectedContents);
            this.footerSplitContainer.Panel2.Padding = new System.Windows.Forms.Padding(3);
            this.footerSplitContainer.Size = new System.Drawing.Size(1128, 759);
            this.footerSplitContainer.SplitterDistance = 661;
            this.footerSplitContainer.SplitterWidth = 3;
            this.footerSplitContainer.TabIndex = 2;
            // 
            // dataGridSplitContainer
            // 
            this.dataGridSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.dataGridSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.dataGridSplitContainer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridSplitContainer.Name = "dataGridSplitContainer";
            this.dataGridSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // dataGridSplitContainer.Panel1
            // 
            this.dataGridSplitContainer.Panel1.Controls.Add(this.headerSplitContainer);
            // 
            // dataGridSplitContainer.Panel2
            // 
            this.dataGridSplitContainer.Panel2.Controls.Add(this.dataGridView);
            this.dataGridSplitContainer.Panel2.Padding = new System.Windows.Forms.Padding(3);
            this.dataGridSplitContainer.Size = new System.Drawing.Size(1128, 661);
            this.dataGridSplitContainer.SplitterDistance = 86;
            this.dataGridSplitContainer.SplitterWidth = 3;
            this.dataGridSplitContainer.TabIndex = 1;
            // 
            // headerSplitContainer
            // 
            this.headerSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.headerSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.headerSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.headerSplitContainer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.headerSplitContainer.Name = "headerSplitContainer";
            // 
            // headerSplitContainer.Panel1
            // 
            this.headerSplitContainer.Panel1.Controls.Add(this.groupBox1);
            this.headerSplitContainer.Panel1.Padding = new System.Windows.Forms.Padding(3);
            // 
            // headerSplitContainer.Panel2
            // 
            this.headerSplitContainer.Panel2.Controls.Add(this.information);
            this.headerSplitContainer.Panel2.Padding = new System.Windows.Forms.Padding(3);
            this.headerSplitContainer.Size = new System.Drawing.Size(1128, 86);
            this.headerSplitContainer.SplitterDistance = 386;
            this.headerSplitContainer.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.resetButton);
            this.groupBox1.Controls.Add(this.dateNextButton);
            this.groupBox1.Controls.Add(this.dateBackButton);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.infoCheckBox);
            this.groupBox1.Controls.Add(this.warnCheckBox);
            this.groupBox1.Controls.Add(this.errorCheckBox);
            this.groupBox1.Controls.Add(this.fatalCheckBox);
            this.groupBox1.Controls.Add(this.dateComboBox);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(380, 80);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "フィルタ";
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(303, 19);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(70, 23);
            this.resetButton.TabIndex = 3;
            this.resetButton.Text = "リセット";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // dateNextButton
            // 
            this.dateNextButton.Location = new System.Drawing.Point(242, 19);
            this.dateNextButton.Name = "dateNextButton";
            this.dateNextButton.Size = new System.Drawing.Size(24, 23);
            this.dateNextButton.TabIndex = 3;
            this.dateNextButton.Text = "＞";
            this.dateNextButton.UseVisualStyleBackColor = true;
            this.dateNextButton.Click += new System.EventHandler(this.dateNextButton_Click);
            // 
            // dateBackButton
            // 
            this.dateBackButton.Location = new System.Drawing.Point(212, 19);
            this.dateBackButton.Name = "dateBackButton";
            this.dateBackButton.Size = new System.Drawing.Size(24, 23);
            this.dateBackButton.TabIndex = 3;
            this.dateBackButton.Text = "＜";
            this.dateBackButton.UseVisualStyleBackColor = true;
            this.dateBackButton.Click += new System.EventHandler(this.dateBackButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "ログレベル：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "日時：";
            // 
            // infoCheckBox
            // 
            this.infoCheckBox.AutoSize = true;
            this.infoCheckBox.Checked = true;
            this.infoCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.infoCheckBox.Location = new System.Drawing.Point(280, 51);
            this.infoCheckBox.Name = "infoCheckBox";
            this.infoCheckBox.Size = new System.Drawing.Size(96, 19);
            this.infoCheckBox.TabIndex = 1;
            this.infoCheckBox.Text = "INFO・DEBUG";
            this.infoCheckBox.UseVisualStyleBackColor = true;
            this.infoCheckBox.CheckedChanged += new System.EventHandler(this.filterChanged);
            // 
            // warnCheckBox
            // 
            this.warnCheckBox.AutoSize = true;
            this.warnCheckBox.Checked = true;
            this.warnCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.warnCheckBox.Location = new System.Drawing.Point(213, 51);
            this.warnCheckBox.Name = "warnCheckBox";
            this.warnCheckBox.Size = new System.Drawing.Size(61, 19);
            this.warnCheckBox.TabIndex = 1;
            this.warnCheckBox.Text = "WARN";
            this.warnCheckBox.UseVisualStyleBackColor = true;
            this.warnCheckBox.CheckedChanged += new System.EventHandler(this.filterChanged);
            // 
            // errorCheckBox
            // 
            this.errorCheckBox.AutoSize = true;
            this.errorCheckBox.Checked = true;
            this.errorCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.errorCheckBox.Location = new System.Drawing.Point(145, 51);
            this.errorCheckBox.Name = "errorCheckBox";
            this.errorCheckBox.Size = new System.Drawing.Size(62, 19);
            this.errorCheckBox.TabIndex = 1;
            this.errorCheckBox.Text = "ERROR";
            this.errorCheckBox.UseVisualStyleBackColor = true;
            this.errorCheckBox.CheckedChanged += new System.EventHandler(this.filterChanged);
            // 
            // fatalCheckBox
            // 
            this.fatalCheckBox.AutoSize = true;
            this.fatalCheckBox.Checked = true;
            this.fatalCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.fatalCheckBox.Location = new System.Drawing.Point(79, 51);
            this.fatalCheckBox.Name = "fatalCheckBox";
            this.fatalCheckBox.Size = new System.Drawing.Size(60, 19);
            this.fatalCheckBox.TabIndex = 1;
            this.fatalCheckBox.Text = "FATAL";
            this.fatalCheckBox.UseVisualStyleBackColor = true;
            this.fatalCheckBox.CheckedChanged += new System.EventHandler(this.filterChanged);
            // 
            // dateComboBox
            // 
            this.dateComboBox.FormattingEnabled = true;
            this.dateComboBox.Location = new System.Drawing.Point(78, 19);
            this.dateComboBox.Name = "dateComboBox";
            this.dateComboBox.Size = new System.Drawing.Size(121, 23);
            this.dateComboBox.TabIndex = 0;
            this.dateComboBox.SelectedValueChanged += new System.EventHandler(this.filterChanged);
            // 
            // information
            // 
            this.information.Dock = System.Windows.Forms.DockStyle.Fill;
            this.information.Location = new System.Drawing.Point(3, 3);
            this.information.Name = "information";
            this.information.Size = new System.Drawing.Size(732, 80);
            this.information.TabIndex = 0;
            this.information.Text = "";
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.Location = new System.Drawing.Point(3, 3);
            this.dataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView.MultiSelect = false;
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersVisible = false;
            this.dataGridView.RowHeadersWidth = 51;
            this.dataGridView.RowTemplate.Height = 29;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView.Size = new System.Drawing.Size(1122, 566);
            this.dataGridView.TabIndex = 0;
            this.dataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView_CellFormatting);
            this.dataGridView.SelectionChanged += new System.EventHandler(this.dataGridView_SelectionChanged);
            // 
            // selectedContents
            // 
            this.selectedContents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.selectedContents.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.selectedContents.Location = new System.Drawing.Point(3, 3);
            this.selectedContents.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.selectedContents.Name = "selectedContents";
            this.selectedContents.Size = new System.Drawing.Size(1122, 89);
            this.selectedContents.TabIndex = 0;
            this.selectedContents.Text = "";
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1128, 783);
            this.Controls.Add(this.footerSplitContainer);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form";
            this.Text = "HeadControllerCsvAnalyzerApp";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.footerSplitContainer.Panel1.ResumeLayout(false);
            this.footerSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.footerSplitContainer)).EndInit();
            this.footerSplitContainer.ResumeLayout(false);
            this.dataGridSplitContainer.Panel1.ResumeLayout(false);
            this.dataGridSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSplitContainer)).EndInit();
            this.dataGridSplitContainer.ResumeLayout(false);
            this.headerSplitContainer.Panel1.ResumeLayout(false);
            this.headerSplitContainer.Panel1.PerformLayout();
            this.headerSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.headerSplitContainer)).EndInit();
            this.headerSplitContainer.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem ファイルToolStripMenuItem;
        private ToolStripMenuItem OpenToolStripMenuItem;
        private SplitContainer footerSplitContainer;
        private DataGridView dataGridView;
        private SplitContainer dataGridSplitContainer;
        private SplitContainer headerSplitContainer;
        private RichTextBox selectedContents;
        private GroupBox groupBox1;
        private ComboBox dateComboBox;
        private RichTextBox information;
        private Button dateNextButton;
        private Button dateBackButton;
        private Label label2;
        private Label label1;
        private CheckBox infoCheckBox;
        private CheckBox warnCheckBox;
        private CheckBox errorCheckBox;
        private CheckBox fatalCheckBox;
        private Button resetButton;
    }
}